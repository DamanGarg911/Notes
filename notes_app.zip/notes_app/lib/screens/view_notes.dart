import 'package:flutter/material.dart';

import '../models/note_model.dart';
import 'package:flutter/material.dart';
import 'package:notes_app/models/note_model.dart';

class NoteView extends StatelessWidget {
  const NoteView(
      {super.key,
      required this.note,
      required this.index,
      required this.TheNoteDeleted});

  final Note note;
  final int index;

  final Function(int) TheNoteDeleted;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Note View",
          style: TextStyle(fontFamily: 'Mooli'),
        ),
        actions: [
          IconButton(
            onPressed: () {
              showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: const Text(
                        "Delete This ?",
                        style: TextStyle(fontFamily: 'Mooli'),
                      ),
                      content: Text(
                        "Note ${note.title} will be deleted!",
                        style: TextStyle(fontFamily: 'Mooli'),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                            TheNoteDeleted(index);
                            Navigator.of(context).pop();
                          },
                          child: const Text(
                            "DELETE",
                            style: TextStyle(fontFamily: 'Mooli'),
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: const Text(
                            "CANCEL",
                            style: TextStyle(fontFamily: 'Mooli'),
                          ),
                        )
                      ],
                    );
                  });
            },
            icon: Icon(Icons.delete),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              note.title,
              style: const TextStyle(fontSize: 28, fontFamily: 'Mooli'),
            ),
            const SizedBox(
              height: 15,
            ),
            Text(
              note.body,
              style: const TextStyle(fontSize: 20, fontFamily: 'Mooli'),
            ),
          ],
        ),
      ),
    );
  }
}
